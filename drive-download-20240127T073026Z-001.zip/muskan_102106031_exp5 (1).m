clc
clear all
t=-10:1:10;
t1=-10:1:10;
unitstep1=t>=0;
subplot(3,2,1)
stem(t,unitstep1,'b')
grid on
title('u(n)')
% axis equal
unitstep2=t1>=6;
subplot(3,2,2)
stem(t1,unitstep2,'m')
title('u(n-6)')
% axis equal
grid on
subplot(3,2,3)
u3=unitstep1-unitstep2;
stem(t,u3,'r')
title('x(n)=u(n)-u(n-6)')
% axis equal
grid on

%% part1
h1 = u3;
% c = conv(u3 ,h)
% subplot(3,2,4)
% stem(c)

%% part 2

