% clc
% clear
% A =[1 2 3 4 ;5 6 7 8 ;7 3 2 5;1 9 7 3 ]
% B = A(1:2,1:2)
% m = 1:1:10
% % x = 0:pi/100:2*pi;
% x = 1:0.1:10;
% y = sin(x);
% subplot(1,2,1),plot(x,y,'--ro','linewidth',2)
% xlabel('x')
% ylabel('y')
% title('x vs y')

% % hold on
% % x1 = 1:0.1:10;
% y1 = cos(x);
% subplot(1,2,2),plot(x,y1,'--g','linewidth',2)
% % hold on 
% xlabel('x')
% ylabel('y')
% title('x vs y')
% grid on

%--ques 1 array using increment

% clc 
% clear all 
% a = 1:1:10

%--ques 2 find min value 

% A = [1 1 1;1 2 2; 2 3 4 ]
% B = [1 ;2;1]
% X= inv(A)*B
% A = [4 1 3; 2 6 7 ;3 1 8]
% min(A)
% min(min(A))
% [i,j] = find (A == min(min(A)))
% A(i,j)=10
% A

%-- ques 3 sort matrix

% A = [1 1 1;1 2 2; 2 3 4 ]
%sort(A)
% sort(A')


%-- ques 4 plot line 

% clc 
% clear all
% format rational
% A = [2,4];
% B= 12;
% x1 = 1:1:10;
% y1 = (B(1)-A(1,1)*x1)/(A(1,2));
% y1=max(0,y1);
% plot(x1,y1,'m','linewidth',2)
% xlabel('x')
% ylabel('y')
% title('x vs y')

%-- ques 5 intersection point 

% clc 
% clear all
% A = [2,4];
% B= 12;
% x1 = 1:1:10;
% y1 = (B-A(1,1)*x1)/(A(1,2));
% A1 = [3,2];
% B1 = 12;
% y2 = (B1-A1(1,1)*x1)/(A1(1,2));
% y1=max(0,y1);
% plot(x1,y1,'m','linewidth',2)
% hold on
% y2=max(0,y2);
% plot(x1,y2,'r','linewidth',2)
% hold on 
% xlabel('x')
% ylabel('y')
% title('x vs y')
% 
% intersection = find(y2==y1)
% y1=(B1-A1(1,1)*intersection)/(A1(1,2))
