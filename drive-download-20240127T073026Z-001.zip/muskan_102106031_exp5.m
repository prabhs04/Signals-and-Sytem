clc
clear all
t=-10:1:10;
t1=-10:1:10;
unitstep1=t>=0;
subplot(3,2,1)
stem(t,unitstep1,'b')
grid on
title('u(n)')
% axis equal
unitstep2=t1>=6;
subplot(3,2,2)
stem(t1,unitstep2,'m')
title('u(n-6)')
% axis equal
grid on
subplot(3,2,3)
u3=unitstep1-unitstep2;
stem(t,u3,'r')
title('x(n)=u(n)-u(n-6)')
% axis equal
grid on
%% part1
h1 = u3;
% c = conv(u3 ,h)
% subplot(3,2,4)
% stem(c)
%% part 2
h2 =flip(h1);
h2 = t1>=15;
syms c1
c1=0;
for t = -200:1:200
    for t1 = -200:1:200
c1 = c1+ sum(u3.*h2)
    t1 = t1+1;
    end
    t = t+1;
end
subplot(3,2,4)
stem(c1)
